import torch
from einops import rearrange, repeat
from .cuda_splatting import render_cuda
from utils.geometry import normalize_intrinsics


def build_covariance_from_scaling_rotation(scales, rotations):
    """
    Build 3D covariance matrix from scales and rotation quaternions.
    This ensures the covariance is always positive semi-definite.
    
    Args:
        scales: (B, H, W, 3) scale parameters
        rotations: (B, H, W, 4) quaternion rotations (w, x, y, z)
    
    Returns:
        covariances: (B, H, W, 3, 3) covariance matrices
    """
    # Ensure scales are positive and have minimum value
    # CRITICAL: Minimum scale must be large enough to prevent buffer overflow
    # After 10x scene scaling, we need scales ~0.01-0.1 for stable rasterization
    scales = torch.clamp(scales, min=0.01, max=100.0)  # Minimum scale of 0.01
    
    # Normalize quaternions
    rotations = rotations / (rotations.norm(dim=-1, keepdim=True) + 1e-8)
    
    # Extract quaternion components
    w, x, y, z = rotations[..., 0], rotations[..., 1], rotations[..., 2], rotations[..., 3]
    
    # Build rotation matrix from quaternion
    # R = [[1-2(y²+z²), 2(xy-wz), 2(xz+wy)],
    #      [2(xy+wz), 1-2(x²+z²), 2(yz-wx)],
    #      [2(xz-wy), 2(yz+wx), 1-2(x²+y²)]]
    
    R = torch.zeros((*rotations.shape[:-1], 3, 3), device=rotations.device, dtype=rotations.dtype)
    
    R[..., 0, 0] = 1 - 2 * (y**2 + z**2)
    R[..., 0, 1] = 2 * (x*y - w*z)
    R[..., 0, 2] = 2 * (x*z + w*y)
    
    R[..., 1, 0] = 2 * (x*y + w*z)
    R[..., 1, 1] = 1 - 2 * (x**2 + z**2)
    R[..., 1, 2] = 2 * (y*z - w*x)
    
    R[..., 2, 0] = 2 * (x*z - w*y)
    R[..., 2, 1] = 2 * (y*z + w*x)
    R[..., 2, 2] = 1 - 2 * (x**2 + y**2)
    
    # Build scale matrix S (diagonal)
    S = torch.zeros((*scales.shape[:-1], 3, 3), device=scales.device, dtype=scales.dtype)
    S[..., 0, 0] = scales[..., 0]
    S[..., 1, 1] = scales[..., 1]
    S[..., 2, 2] = scales[..., 2]
    
    # Compute covariance: Σ = R S Sᵀ Rᵀ = R S² Rᵀ
    # Since S is diagonal, S² is just scales squared on diagonal
    RS = torch.matmul(R, S)
    covariance = torch.matmul(RS, RS.transpose(-1, -2))
    
    return covariance


class DecoderSplattingCUDA(torch.nn.Module):
    def __init__(self, background_color):
        super().__init__()
        self.register_buffer(
            "background_color",
            torch.tensor(background_color, dtype=torch.float32),
            persistent=False,
        )

    def forward(self, batch, pred1, pred2, image_shape):
        # --- camera poses & intrinsics ---
        base_pose = batch['context'][0]['camera_pose']  # [b, 4, 4]
        inv_base_pose = torch.inverse(base_pose)
        extrinsics = torch.stack(
            [target_view['camera_pose'] for target_view in batch['target']], dim=1
        )  # [b, v, 4, 4]
        intrinsics = torch.stack(
            [target_view['camera_intrinsics'] for target_view in batch['target']], dim=1
        )  # [b, v, 4, 4]
        intrinsics = normalize_intrinsics(intrinsics, image_shape)[..., :3, :3]

        # rotate extrinsics into coord system of first context view
        extrinsics = inv_base_pose[:, None, :, :] @ extrinsics  # [b, v, 4, 4]

        # --- CRITICAL FIX: Rebuild covariances from scales and rotations ---
        # This ensures they are always positive semi-definite
        ##print("\n[DEBUG] Rebuilding covariances from scales and rotations...")
        
        # Check if we have scales and rotations
        if 'scales' in pred1 and 'rotations' in pred1:
            #print("[INFO] Using scales and rotations to build covariances")
            cov1 = build_covariance_from_scaling_rotation(pred1['scales'], pred1['rotations'])
            cov2 = build_covariance_from_scaling_rotation(pred2['scales'], pred2['rotations'])
            
            # print(f"Rebuilt cov1 range: [{cov1.min().item():.4e}, {cov1.max().item():.4e}]")
            # print(f"Rebuilt cov2 range: [{cov2.min().item():.4e}, {cov2.max().item():.4e}]")
        else:
            # Fallback: use provided covariances with regularization
            # print("[WARN] No scales/rotations found, using provided covariances with regularization")
            cov1 = pred1["covariances"]
            cov2 = pred2["covariances"]
            
            # Add identity regularization to ensure positive semi-definite
            MIN_EIGENVALUE = 1e-4
            identity = torch.eye(3, device=cov1.device, dtype=cov1.dtype)
            cov1 = cov1 + MIN_EIGENVALUE * identity
            cov2 = cov2 + MIN_EIGENVALUE * identity
            
            # print(f"Regularized cov1 range: [{cov1.min().item():.4e}, {cov1.max().item():.4e}]")
            # print(f"Regularized cov2 range: [{cov2.min().item():.4e}, {cov2.max().item():.4e}]")

        # --- gaussian parameters from both views ---
        means = torch.stack([pred1["means"], pred2["means_in_other_view"]], dim=1)
        covariances = torch.stack([cov1, cov2], dim=1)
        harmonics = torch.stack([pred1["sh"], pred2["sh"]], dim=1)
        opacities = torch.stack([pred1["opacities"], pred2["opacities"]], dim=1)

        b, v, Hf, Wf, _ = means.shape
        near = torch.full((b, v), 0.1, device=means.device)
        far = torch.full((b, v), 1000.0, device=means.device)

        # --- DEBUG: print shapes & gaussian count ---
        num_gauss_per_scene = v * Hf * Wf
        # print(
        #     f"[DEBUG] DecoderSplattingCUDA: "
        #     f"b={b}, v={v}, Hf={Hf}, Wf={Wf}, "
        #     f"image_shape={image_shape}, gauss_per_scene={num_gauss_per_scene}"
        # )

        # --- FLATTEN GAUSSIANS PER SCENE ---
        means_flat = rearrange(means, "b v h w c -> b (v h w) c")
        cov_flat = rearrange(covariances, "b v h w i j -> b (v h w) i j")
        harm_flat = rearrange(harmonics, "b v h w c d_sh -> b (v h w) c d_sh")
        opa_flat = rearrange(opacities, "b v h w 1 -> b (v h w)")

        # --- HARD SAFETY CAP ON GAUSSIANS ---
        MAX_GAUSS = 200_000
        if num_gauss_per_scene > MAX_GAUSS:
            idx = torch.randperm(num_gauss_per_scene, device=means.device)[:MAX_GAUSS]
            means_flat = means_flat[:, idx]
            cov_flat = cov_flat[:, idx]
            harm_flat = harm_flat[:, idx]
            opa_flat = opa_flat[:, idx]
            # print(
            #     f"[WARN] Clipped Gaussians per scene from "
            #     f"{num_gauss_per_scene} to {MAX_GAUSS}"
            # )
            num_gauss_per_scene = MAX_GAUSS

        # --- REPEAT GAUSSIANS FOR EACH TARGET VIEW (CAMERA) ---
        means_rep = repeat(means_flat, "b g c -> (b v) g c", v=v)
        cov_rep = repeat(cov_flat, "b g i j -> (b v) g i j", v=v)
        harm_rep = repeat(harm_flat, "b g c d_sh -> (b v) g c d_sh", v=v)
        opa_rep = repeat(opa_flat, "b g -> (b v) g", v=v)

        #print(f"Final covariances range: [{cov_rep.min().item():.4e}, {cov_rep.max().item():.4e}]")
        
        # Check diagonal values to ensure they're reasonable
        diag_vals = torch.diagonal(cov_rep, dim1=-2, dim2=-1)
        # print(f"Covariance diagonal range: [{diag_vals.min().item():.4e}, {diag_vals.max().item():.4e}]")
        # print(f"Covariance diagonal mean: {diag_vals.mean().item():.4e}")
        
        # If diagonals are still too small, force a minimum
        if diag_vals.max().item() < 1e-3:
            print("[CRITICAL] Covariance scales too small, applying emergency fix!")
            # Add minimum to diagonal
            identity = torch.eye(3, device=cov_rep.device, dtype=cov_rep.dtype)
            cov_rep = cov_rep + 0.01 * identity

        # --- CALL CUDA RASTERIZER ---
        # TEMPORARY: Try without scale_invariant mode to isolate the issue
        #print("\n[DEBUG] Calling render_cuda with scale_invariant=False for debugging...")
        color = render_cuda(
            rearrange(extrinsics, "b v i j -> (b v) i j"),
            rearrange(intrinsics, "b v i j -> (b v) i j"),
            rearrange(near, "b v -> (b v)"),
            rearrange(far, "b v -> (b v)"),
            image_shape,
            repeat(self.background_color, "c -> (b v) c", b=b, v=v),
            means_rep,
            cov_rep,
            harm_rep,
            opa_rep,
            scale_invariant=False,  # DISABLE scale_invariant to test
        )

        color = rearrange(color, "(b v) c h w -> b v c h w", b=b, v=v)
        return color, None