import sys
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional

# --- 1. SYSTEM PATH SETUP ---
current_file_path = os.path.abspath(__file__)
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_file_path))))
croco_root = os.path.join(project_root, 'src', 'mast3r_src', 'dust3r', 'croco')
if croco_root not in sys.path:
    sys.path.insert(0, croco_root)

# --- 2. IMPORT ENCODER ---
try:
    from src.mast3r_src.dust3r.croco.models.croco import CroCoNet as _CroCoEncoder
except ImportError:
    try:
        from models.croco import CroCoNet as _CroCoEncoder
    except ImportError as e:
        raise RuntimeError(f"Could not import CroCoNet. Checked path: {croco_root}. Error: {e}")


class PatchEmbedFlattener(nn.Module):
    """
    Wrapper that ensures patch_embed always returns (tokens, pos) tuple 
    where tokens are in (B, N, C) format, never (B, C, H, W).
    """
    def __init__(self, original_patch_embed):
        super().__init__()
        self.original_patch_embed = original_patch_embed
    
    def forward(self, x):
        # Call original patch_embed
        result = self.original_patch_embed(x)
        
        # Handle tuple return (x, pos)
        if isinstance(result, tuple):
            x_out, pos = result
        else:
            # If single tensor, create dummy pos
            x_out = result
            pos = None
        
        # Flatten if spatial: (B, C, H, W) -> (B, N, C)
        if x_out.ndim == 4:
            B, C, H, W = x_out.shape
            x_out = x_out.flatten(2).transpose(1, 2)  # (B, C, H*W) -> (B, H*W, C)
        elif x_out.ndim != 3:
            raise ValueError(f"Expected patch_embed output to be 3D or 4D, got {x_out.ndim}D with shape {x_out.shape}")
        
        # Verify we have correct shape
        assert x_out.ndim == 3, f"x_out must be 3D, got {x_out.ndim}D"
        
        # Always return tuple (tokens, pos)
        return x_out, pos
    
    def __getattr__(self, name):
        # Delegate attribute access to the original patch_embed
        try:
            return super().__getattr__(name)
        except AttributeError:
            return getattr(self.original_patch_embed, name)


class CroCoBackbone(nn.Module):
    def __init__(self, ckpt_path: Optional[str] = None, out_dim: int = 20, target_stride: int = 16, use_v2: bool = True):
        super().__init__()
        
        # Initialize with standard 224 size
        self.patch_size = 16
        
        # --- FIX: OVERRIDE DEFAULTS ---
        # We explicitly set decoder dims to 768 to match the checkpoint.
        self.encoder = _CroCoEncoder(
            img_size=224, 
            patch_size=self.patch_size, 
            enc_embed_dim=768, 
            enc_depth=12, 
            enc_num_heads=12,
            dec_embed_dim=768,  # <--- Critical Fix: Default is 512, Checkpoint is 768
            dec_depth=12, 
            dec_num_heads=12
        )

        # Wrap the patch_embed to ensure it returns flattened tokens
        self.encoder.patch_embed = PatchEmbedFlattener(self.encoder.patch_embed)
        
        # Monkey-patch _encode_image to handle our wrapper correctly
        self._original_encode_image = self.encoder._encode_image
        self.encoder._encode_image = self._patched_encode_image

        # Load Checkpoint
        if ckpt_path:
            print(f"[CroCoBackbone] Loading checkpoint: {ckpt_path}")
            if os.path.exists(ckpt_path):
                sd = torch.load(ckpt_path, map_location="cpu")
                if 'model' in sd: sd = sd['model']
                elif 'state_dict' in sd: sd = sd['state_dict']
                
                # Load into encoder
                missing, unexpected = self.encoder.load_state_dict(sd, strict=False)
                print(f"  Missing keys: {len(missing)}, Unexpected keys: {len(unexpected)}")
            else:
                print(f"[CroCoBackbone] WARNING: Checkpoint not found at {ckpt_path}")

        # Projection Layer: Input is now 768 (from decoder) -> Output 256
        self.proj = nn.Conv2d(768, out_dim, kernel_size=1)
        self.out_dim = out_dim
        self.target_stride = target_stride
    
    def _patched_encode_image(self, image, do_mask=False):
        """
        Patched version of _encode_image that properly handles our wrapped patch_embed.
        """
        # Get patch embeddings (now guaranteed to be flattened)
        x, pos = self.encoder.patch_embed(image)
        
        B, N, C = x.shape
        
        # Create dummy masks if needed
        masks = None
        if do_mask:
            masks = torch.zeros(B, N, dtype=torch.bool, device=x.device)
        
        # Get positional encoding
        pos_embed = None
        if self.encoder.enc_pos_embed is not None:
            pos_embed = self.encoder.enc_pos_embed
            if pos_embed.ndim == 2:
                pos_embed = pos_embed.unsqueeze(0)
        
        # Run through encoder blocks
        for blk in self.encoder.enc_blocks:
            x = blk(x, pos_embed)
        
        # Final norm
        x = self.encoder.enc_norm(x)
        
        return x, pos, masks

    def _resize_pos_embed(self, H, W):
        """
        Dynamically interpolates the encoder's positional embeddings 
        to match the new input resolution (H, W).
        """
        # Update img_size on the inner patch embedding layer
        patch_embed = self.encoder.patch_embed
        if isinstance(patch_embed, PatchEmbedFlattener):
            inner_embed = patch_embed.original_patch_embed
        else:
            inner_embed = patch_embed
            
        if hasattr(inner_embed, 'img_size'):
            inner_embed.img_size = (H, W)

        # Get current pos_embed
        pos_embed = self.encoder.enc_pos_embed
        if pos_embed is None:
            return

        # Ensure pos_embed is (1, N, C)
        if pos_embed.ndim == 2:
            pos_embed = pos_embed.unsqueeze(0)

        # Calculate grid sizes
        N_curr = pos_embed.shape[1]
        S_curr = int(N_curr ** 0.5) 
        
        H_new, W_new = H // self.patch_size, W // self.patch_size
        
        if (H_new * W_new) != N_curr:
            # Reshape to (1, C, S, S) for interpolation
            C = pos_embed.shape[2]
            pos_embed = pos_embed.transpose(1, 2).reshape(1, C, S_curr, S_curr)
            
            # Interpolate
            new_pos_embed = F.interpolate(
                pos_embed, size=(H_new, W_new), mode='bicubic', align_corners=False
            )
            
            # Flatten back to (1, N, C)
            new_pos_embed = new_pos_embed.flatten(2).transpose(1, 2)
            
            # Update the model buffer
            self.encoder.enc_pos_embed = new_pos_embed

    def forward(self, x):
        B, C, H, W = x.shape
        
        # 1. Resize Position Embeddings for current resolution
        self._resize_pos_embed(H, W)
        
        # 2. Run encoder - uses our patched _encode_image
        tokens, pos, masks = self.encoder._encode_image(x, do_mask=False)
        
        # 3. Process Output
        B_, N, D = tokens.shape
        H_enc, W_enc = H // self.patch_size, W // self.patch_size
        
        # (B, N, D) -> (B, D, H, W)
        feat = tokens.transpose(1, 2).reshape(B_, D, H_enc, W_enc)
        
        # Project and adjust stride
        proj = self.proj(feat) 
        
        H_t = (H + self.target_stride - 1) // self.target_stride
        W_t = (W + self.target_stride - 1) // self.target_stride
        
        if (proj.shape[-2], proj.shape[-1]) != (H_t, W_t):
            proj = F.interpolate(proj, size=(H_t, W_t), mode='bilinear', align_corners=False)
            
        return proj