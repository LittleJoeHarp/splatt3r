# src/models/registry.py
import torch.nn as nn
from typing import Dict, Type, Any

# Import your backbones here
from src.models.backbones.croco import CroCoBackbone

# Define the registry
BACKBONES: Dict[str, Type[nn.Module]] = {
    "croco": CroCoBackbone,
    # Future additions:
    # "mast3r": Mast3RBackbone,
    # "dinov2": DinoV2Backbone,
}

def get_backbone(name: str, **kwargs) -> nn.Module:
    """
    Instantiates a backbone by name.
    
    Args:
        name (str): Key from BACKBONES dict (e.g. "croco")
        **kwargs: Arguments passed directly to the backbone constructor.
                  (e.g. ckpt_path, out_dim)
    """
    if name not in BACKBONES:
        available = list(BACKBONES.keys())
        raise KeyError(f"Backbone '{name}' not found. Available: {available}")
    
    backbone_cls = BACKBONES[name]
    return backbone_cls(**kwargs)