#!/usr/bin/env python3
"""
Training script for Splatt3R (MASt3R/CroCo + PixelSplat integration).
"""
import json
import os
import sys
import einops
import lightning as L
import lpips
import omegaconf
import torch
import torch.nn as nn
import torch.nn.functional as F
import wandb

# --- PATH SETUP ---
sys.path.append('src/pixelsplat_src')
sys.path.append('src/mast3r_src')
sys.path.append('src/mast3r_src/dust3r')

# --- IMPORTS ---
from src.mast3r_src.dust3r.dust3r.losses import L21
from src.mast3r_src.mast3r.losses import ConfLoss, Regr3D
import src.mast3r_src.mast3r.model as mast3r_model
import src.pixelsplat_src.benchmarker as benchmarker
import src.pixelsplat_src.decoder_splatting_cuda as pixelsplat_decoder
import utils.compute_ssim as compute_ssim
import utils.export as export
import utils.geometry as geometry
import utils.loss_mask as loss_mask
import utils.sh_utils as sh_utils
import workspace
import data.scannetpp.scannetpp as scannetpp

from src.models.backbones.registry import get_backbone
import data.co3d as co3d_dataset


# --- ROBUST GAUSSIAN HEAD ---
class GaussianPredictionHead(nn.Module):
    def __init__(self, in_dim=256):
        super().__init__()
        self.conv1 = nn.Conv2d(in_dim, in_dim, kernel_size=3, padding=1)
        self.act = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(in_dim, 12, kernel_size=1)
        
        # Initialize biases for stability
        self.conv2.bias.data[0] = -2.0  # Depth: sigmoid(-2) * 10 + 0.5 ≈ 1.7
        self.conv2.bias.data[1:4] = -5.0  # Scales: Start very small
        self.conv2.bias.data[4:8] = torch.tensor([1.0, 0.0, 0.0, 0.0])  # Identity Rot
        self.conv2.bias.data[8] = 0.0  # Opacity
        self.conv2.bias.data[9:12] = 0.0  # Color

    def forward(self, x):
        # Sanitize Input
        if torch.isnan(x).any():
            x = torch.nan_to_num(x, nan=0.0)
            
        x = self.act(self.conv1(x))
        x = self.conv2(x)
        depth_raw, scale_raw, rot_raw, opacity_raw, color_raw = torch.split(
            x, [1, 3, 4, 1, 3], dim=1
        )
        
        # 1. Depth: Strictly clamped positive range
        depth = F.sigmoid(depth_raw) * 10.0 + 0.5
        depth = torch.clamp(depth, min=0.5, max=20.0)
        
        # 2. Scale: Strictly small max size
        scales = F.sigmoid(scale_raw) * 0.05
        scales = torch.clamp(scales, min=1e-6, max=0.05)
        
        # 3. Rotation: Safe Normalize
        rotations = F.normalize(rot_raw, dim=1, eps=1e-6)
        
        # 4. Opacity
        opacity = F.sigmoid(opacity_raw)
        opacity = torch.clamp(opacity, min=0.01, max=0.99)
        
        # 5. SH / Color
        sh = F.sigmoid(color_raw)
        
        return depth, scales, rotations, opacity, sh


def unproject_depth(depth, intrinsics, stride=16):
    """
    Unprojects depth map to 3D points on feature grid.
    """
    B, _, H_feat, W_feat = depth.shape 
    device = depth.device
    
    y, x = torch.meshgrid(
        torch.arange(H_feat, device=device).float(), 
        torch.arange(W_feat, device=device).float(), 
        indexing='ij'
    )
    
    x = (x * stride) + (stride / 2.0)
    y = (y * stride) + (stride / 2.0)
    
    x = x.unsqueeze(0).expand(B, -1, -1)
    y = y.unsqueeze(0).expand(B, -1, -1)
    
    fx = intrinsics[:, 0, 0].view(B, 1, 1)
    fy = intrinsics[:, 1, 1].view(B, 1, 1)
    cx = intrinsics[:, 0, 2].view(B, 1, 1)
    cy = intrinsics[:, 1, 2].view(B, 1, 1)
    
    z = depth.squeeze(1)
    z = torch.clamp(z, min=0.1, max=100.0)  # Safety clamp
    
    X = (x - cx) * z / fx
    Y = (y - cy) * z / fy
    
    # Clamp spatial extents to reasonable box (e.g. +/- 50 meters)
    X = torch.clamp(X, -50.0, 50.0)
    Y = torch.clamp(Y, -50.0, 50.0)
    
    means = torch.stack([X, Y, z], dim=-1)
    return means


def check_gaussian_params(pred, name=""):
    """Debug helper to warn about invalid Gaussian parameters."""
    means = pred['means']
    scales = pred['scales']
    
    if torch.isnan(means).any() or torch.isinf(means).any():
        print(f"⚠️ [{name}] NaN/Inf in means!")
    if torch.isnan(scales).any() or torch.isinf(scales).any():
        print(f"⚠️ [{name}] NaN/Inf in scales!")
    if (scales > 1.0).any():
        print(f"⚠️ [{name}] Scales explosive > 1.0!")


class MAST3RGaussians(L.LightningModule):

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.benchmarker = benchmarker.Benchmarker()

        backbone_name = self.config.model.get('backbone', 'mast3r')
        self.backbone_name = backbone_name 
        print(f"[Model] Initializing backbone: {backbone_name}")

        if backbone_name == 'mast3r':
            self.encoder = mast3r_model.AsymmetricMASt3R(
                pos_embed='RoPE100',
                patch_embed_cls='ManyAR_PatchEmbed',
                img_size=(512, 512),
                head_type='gaussian_head',
                output_mode='pts3d+gaussian+desc24',
                depth_mode=('exp', -mast3r_model.inf, mast3r_model.inf),
                conf_mode=('exp', 1, mast3r_model.inf),
                enc_embed_dim=1024,
                enc_depth=24,
                enc_num_heads=16,
                dec_embed_dim=768,
                dec_depth=12,
                dec_num_heads=12,
                two_confs=True,
                use_offsets=config.use_offsets,
                sh_degree=config.sh_degree if hasattr(config, 'sh_degree') else 1
            )
            self.encoder.requires_grad_(False)
            if hasattr(self.encoder, 'downstream_head1'):
                self.encoder.downstream_head1.gaussian_dpt.dpt.requires_grad_(True)
                self.encoder.downstream_head2.gaussian_dpt.dpt.requires_grad_(True)
        else:
            self.encoder = get_backbone(
                backbone_name, 
                ckpt_path=self.config.model.get('checkpoint', None),
                out_dim=self.config.model.get('feature_dim', 256),
                target_stride=self.config.model.get('target_stride', 16)
            )
            backbone_out_dim = getattr(
                self.encoder, "out_dim", self.config.model.get('feature_dim', 256)
            )
            assert hasattr(self.encoder, "out_dim"), \
                "Backbone must define self.out_dim"

            backbone_out_dim = self.encoder.out_dim
            print(f"[Model] CroCo backbone output dim = {backbone_out_dim}")

            self.head = GaussianPredictionHead(in_dim=backbone_out_dim)
            print(f"[Model] Backbone '{backbone_name}' output dim: {backbone_out_dim}")

        self.decoder = pixelsplat_decoder.DecoderSplattingCUDA(
            background_color=[0.0, 0.0, 0.0]
        )

        if config.loss.average_over_mask:
            self.lpips_criterion = lpips.LPIPS('vgg', spatial=True)
        else:
            self.lpips_criterion = lpips.LPIPS('vgg')

        if config.loss.mast3r_loss_weight is not None and backbone_name == 'mast3r':
            self.mast3r_criterion = ConfLoss(
                Regr3D(L21, norm_mode='?avg_dis'), alpha=0.2
            )
            self.encoder.downstream_head1.requires_grad_(True)
            self.encoder.downstream_head2.requires_grad_(True)

        self.save_hyperparameters()

    def predict_single_view(self, view):
        # 1. Get features from backbone
        feats = self.encoder(view['img'])  # CroCo / other backbone output

        # 2. Normalize shape to (B, C, H, W)
        if feats.ndim == 3:
            # (B, N, C) -> (B, C, H, W) assuming square grid
            B, N, C = feats.shape
            S = int(N ** 0.5)
            if S * S != N:
                raise ValueError(
                    f"Encoder output tokens cannot be reshaped to square grid: N={N}"
                )
            feats = feats.view(B, S, S, C).permute(0, 3, 1, 2).contiguous()

        elif feats.ndim == 4:
            # Could be (B, C, H, W) or (B, H, W, C)
            in_channels = self.head.conv1.in_channels

            if feats.shape[1] == in_channels:
                # Already (B, C, H, W)
                pass
            elif feats.shape[-1] == in_channels:
                # (B, H, W, C) -> (B, C, H, W)
                feats = feats.permute(0, 3, 1, 2).contiguous()
            else:
                # Fallback: assume channels is the smallest spatial-like dim
                B, d1, d2, d3 = feats.shape
                # Heuristic: if d1 is clearly the "channel" dim (like 20) and
                # d2, d3 look like H, W (e.g. 33, 33), keep as-is.
                if d1 <= d2 and d1 <= d3:
                    # Treat as (B, C, H, W) with C=d1
                    pass
                elif d3 <= d1 and d3 <= d2:
                    # Treat as (B, H, W, C)
                    feats = feats.permute(0, 3, 1, 2).contiguous()
                else:
                    raise ValueError(
                        f"Cannot infer channel dimension from encoder output shape "
                        f"{feats.shape} and head in_channels={in_channels}"
                    )
        else:
            raise ValueError(f"Unexpected encoder output shape: {feats.shape}")

        # 3. Final sanity check AFTER shape normalization
        assert feats.shape[1] == self.head.conv1.in_channels, \
            f"Feature/head mismatch: feats C={feats.shape[1]} vs head " \
            f"{self.head.conv1.in_channels}"

        # Occasional debug print
        if self.training and torch.rand(1).item() < 0.01:
            print("[DEBUG] encoder feats shape:", feats.shape)

        # 4. Head prediction
        depth, scales, rotations, opacity, sh = self.head(feats)

        # 5. Rearrange parameter maps to (B, H, W, *)
        scales = scales.permute(0, 2, 3, 1)
        rotations = rotations.permute(0, 2, 3, 1)
        opacity = opacity.permute(0, 2, 3, 1)

        # SH shape: (B, H, W, 3, 1)
        sh = sh.permute(0, 2, 3, 1).unsqueeze(-1)

        # 6. Unproject to 3D means
        means = unproject_depth(depth, view['intrinsics'], stride=16)

        # Robustness: clamp NaNs/Infs in means
        if torch.isnan(means).any() or torch.isinf(means).any():
            means = torch.nan_to_num(means, nan=0.0, posinf=10.0, neginf=-10.0)

        # 7. Build covariances
        covariances = geometry.build_covariance(scales, rotations)

        if torch.isnan(covariances).any() or torch.isinf(covariances).any():
            covariances = torch.nan_to_num(
                covariances, nan=1e-6, posinf=1e8, neginf=-1e8
            )

        return {
            'means': means,
            'scales': scales,
            'rotations': rotations,
            'opacities': opacity,
            'sh': sh,
            'covariances': covariances,
            'pts3d': means,
        }

    def forward(self, view1, view2):
        if self.backbone_name == 'mast3r':
            with torch.no_grad():
                (shape1, shape2), (feat1, feat2), (pos1, pos2) = \
                    self.encoder._encode_symmetrized(view1, view2)
                dec1, dec2 = self.encoder._decoder(feat1, pos1, feat2, pos2)

            pred1 = self.encoder._downstream_head(
                1, [tok.float() for tok in dec1], shape1
            )
            pred2 = self.encoder._downstream_head(
                2, [tok.float() for tok in dec2], shape2
            )
            
            pred1['covariances'] = geometry.build_covariance(
                pred1['scales'], pred1['rotations']
            )
            pred2['covariances'] = geometry.build_covariance(
                pred2['scales'], pred2['rotations']
            )

            new_sh1 = torch.zeros_like(pred1['sh'])
            new_sh2 = torch.zeros_like(pred2['sh'])
            new_sh1[..., 0] = sh_utils.RGB2SH(
                einops.rearrange(view1['original_img'], 'b c h w -> b h w c')
            )
            new_sh2[..., 0] = sh_utils.RGB2SH(
                einops.rearrange(view2['original_img'], 'b c h w -> b h w c')
            )
            pred1['sh'] = pred1['sh'] + new_sh1
            pred2['sh'] = pred2['sh'] + new_sh2

            pred2['pts3d_in_other_view'] = pred2.pop('pts3d')
            pred2['means_in_other_view'] = pred2.pop('means')
            return pred1, pred2
            
        else:
            # --- CROCO PATH ---
            pred1 = self.predict_single_view(view1)
            pred2 = self.predict_single_view(view2)
            
            # Debugging
            if self.training and torch.rand(1).item() < 0.01:
                check_gaussian_params(pred1, "View1")
            
            # Alias keys for decoder
            pred2['means_in_other_view'] = pred2['means']
            pred2['pts3d_in_other_view'] = pred2['pts3d']
            
            return pred1, pred2

    def training_step(self, batch, batch_idx):
        _, _, h, w = batch["context"][0]["img"].shape
        view1, view2 = batch['context']

        pred1, pred2 = self.forward(view1, view2)
        color, _ = self.decoder(batch, pred1, pred2, (h, w))

        mask = loss_mask.calculate_loss_mask(batch)
        loss, mse, lpips, ssim = self.calculate_loss(
            batch, view1, view2, pred1, pred2, color, mask,
            apply_mask=self.config.loss.apply_mask,
            average_over_mask=self.config.loss.average_over_mask,
            calculate_ssim=True
        )

        self.log_metrics('train', loss, mse, lpips, ssim=ssim)
        return loss

    def validation_step(self, batch, batch_idx):
        _, _, h, w = batch["context"][0]["img"].shape
        view1, view2 = batch['context']

        pred1, pred2 = self.forward(view1, view2)
        color, _ = self.decoder(batch, pred1, pred2, (h, w))

        mask = loss_mask.calculate_loss_mask(batch)
        loss, mse, lpips, ssim = self.calculate_loss(
            batch, view1, view2, pred1, pred2, color, mask,
            apply_mask=self.config.loss.apply_mask,
            average_over_mask=self.config.loss.average_over_mask,
            calculate_ssim=True
        )

        self.log_metrics('val', loss, mse, lpips, ssim=ssim)
        return loss

    def test_step(self, batch, batch_idx):
        _, _, h, w = batch["context"][0]["img"].shape
        view1, view2 = batch['context']

        with self.benchmarker.time("encoder"):
            pred1, pred2 = self.forward(view1, view2)
        with self.benchmarker.time("decoder", num_calls=len(batch['target'])):
            color, _ = self.decoder(batch, pred1, pred2, (h, w))

        mask = loss_mask.calculate_loss_mask(batch)
        loss, mse, lpips, ssim = self.calculate_loss(
            batch, view1, view2, pred1, pred2, color, mask,
            apply_mask=self.config.loss.apply_mask,
            average_over_mask=self.config.loss.average_over_mask,
            calculate_ssim=True
        )

        self.log_metrics('test', loss, mse, lpips, ssim=ssim)
        return loss

    def on_test_end(self):
        benchmark_file_path = os.path.join(self.config.save_dir, "benchmark.json")
        self.benchmarker.dump(benchmark_file_path)

    def calculate_loss(
        self, batch, view1, view2, pred1, pred2, color, mask,
        apply_mask=True, average_over_mask=True, calculate_ssim=False
    ):
        """
        Calculates the reconstruction loss (MSE, LPIPS) and optional auxiliary losses.
        """
        # target_color: (B, V, C, H, W)
        target_color = torch.stack(
            [target_view['original_img'] for target_view in batch['target']], dim=1
        )
        predicted_color = color  # (B, V, C, H, W)

        # --- Apply mask in (B, V, 1, H, W) form ---
        if apply_mask:
            if mask.sum() > 0:
                # mask: (B, V, H, W) -> (B, V, 1, H, W)
                mask_exp = mask[:, :, None, :, :]
                target_color = target_color * mask_exp
                predicted_color = predicted_color * mask_exp

        # Flatten for LPIPS / SSIM
        flattened_color = einops.rearrange(
            predicted_color, 'b v c h w -> (b v) c h w'
        )
        flattened_target_color = einops.rearrange(
            target_color, 'b v c h w -> (b v) c h w'
        )
        flattened_mask = einops.rearrange(
            mask, 'b v h w -> (b v) h w'
        )  # (B*V, H, W)

        # --- MSE ---
        rgb_l2_loss = (predicted_color - target_color) ** 2  # (B, V, C, H, W)
        if average_over_mask and mask.sum() > 0:
            # Broadcast mask over channel: (B, V, 1, H, W)
            mask_exp = mask[:, :, None, :, :]
            mse_loss = (rgb_l2_loss * mask_exp).sum() / mask.sum()
        else:
            mse_loss = rgb_l2_loss.mean()

        # --- LPIPS ---
        lpips_loss = self.lpips_criterion(
            flattened_target_color, flattened_color, normalize=True
        )
        if average_over_mask and flattened_mask.sum() > 0:
            # lpips_loss: (B*V, 1, H, W) when spatial=True
            lpips_loss = (lpips_loss * flattened_mask[:, None, ...]).sum() / \
                flattened_mask.sum()
        else:
            lpips_loss = lpips_loss.mean()

        loss = 0
        loss += self.config.loss.mse_loss_weight * mse_loss
        loss += self.config.loss.lpips_loss_weight * lpips_loss

        # --- MASt3R loss (if used) ---
        if (self.config.loss.mast3r_loss_weight is not None and 
            hasattr(self, 'mast3r_criterion')):
            mast3r_loss = self.mast3r_criterion(view1, view2, pred1, pred2)[0]
            loss += self.config.loss.mast3r_loss_weight * mast3r_loss

        # --- SSIM ---
        if calculate_ssim:
            flat_t = flattened_target_color.clamp(0.0, 1.0)
            flat_p = flattened_color.clamp(0.0, 1.0)

            if average_over_mask and flattened_mask.sum() > 0:
                ssim_val = compute_ssim.compute_ssim(flat_t, flat_p, full=True)
                ssim_val = (ssim_val * flattened_mask[:, None, ...]).sum() / \
                    flattened_mask.sum()
            else:
                ssim_val = compute_ssim.compute_ssim(flat_t, flat_p, full=False)
                ssim_val = ssim_val.mean()
            return loss, mse_loss, lpips_loss, ssim_val

        return loss, mse_loss, lpips_loss

    def log_metrics(self, prefix, loss, mse, lpips, ssim=None):
        values = {
            f'{prefix}/loss': loss,
            f'{prefix}/mse': mse,
            f'{prefix}/psnr': -10.0 * mse.log10(),
            f'{prefix}/lpips': lpips,
        }
        if ssim is not None:
            values[f'{prefix}/ssim'] = ssim

        prog_bar = (prefix != 'val')
        sync_dist = (prefix != 'train')
        self.log_dict(
            values, prog_bar=prog_bar, sync_dist=sync_dist,
            batch_size=self.config.data.batch_size, on_step=False, on_epoch=True
        )

    def configure_optimizers(self):
        # Train different params depending on backbone
        if self.backbone_name == 'mast3r':
            params = list(self.encoder.parameters())
        else:
            # encoder + Gaussian head for CroCo / DINOv2 / lightweight, etc.
            params = list(self.encoder.parameters()) + list(self.head.parameters())

        optimizer = torch.optim.Adam(params, lr=self.config.opt.lr)
        scheduler = torch.optim.lr_scheduler.MultiStepLR(
            optimizer,
            [self.config.opt.epochs // 2],
            gamma=0.1
        )
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "interval": "epoch",
                "frequency": 1
            }
        }


def run_experiment(config):
    L.seed_everything(42, workers=True)

    # --- LOGGER SETUP ---
    os.makedirs(os.path.join(config.save_dir, config.name), exist_ok=True)
    loggers = []
    wandb_logger = None
    if config.loggers.use_csv_logger:
        loggers.append(
            L.pytorch.loggers.CSVLogger(save_dir=config.save_dir, name=config.name)
        )
    if config.loggers.use_wandb:
        wandb_logger = L.pytorch.loggers.WandbLogger(
            project='splatt3r',
            name=config.name,
            save_dir=config.save_dir,
            config=omegaconf.OmegaConf.to_container(config)
        )
        loggers.append(wandb_logger)

    # --- MODEL & DATASET SETUP ---
    print('Loading Model')
    model = MAST3RGaussians(config)
    
    # Load Pretrained MASt3R Weights
    backbone_name = config.model.get('backbone', 'mast3r')
    if backbone_name == 'mast3r' and config.get('use_pretrained', False):
        ckpt_path = config.get('pretrained_mast3r_path', None)
        if ckpt_path:
            print(f"[MASt3R] Loading pretrained weights from {ckpt_path}")
            ckpt = torch.load(ckpt_path)
            _ = model.encoder.load_state_dict(ckpt['model'], strict=False)
            del ckpt

    # Robust Dataset Logic
    dataset_name = 'scannet' 
    if config.get('dataset') and config.dataset.get('name'):
        dataset_name = config.dataset.name
    elif config.get('data') and config.data.get('name'):
        dataset_name = config.data.name

    print(f'Building Datasets for {dataset_name}')
    
    if dataset_name == 'co3d':
        data_root = config.data.root 
        train_dataset = co3d_dataset.CO3DDataset(
            root=data_root, split='train', img_size=tuple(config.data.resolution)
        )
        val_dataset = co3d_dataset.CO3DDataset(
            root=data_root, split='val', img_size=tuple(config.data.resolution)
        )
    else:
        train_dataset = scannetpp.get_scannet_dataset(
            config.data.root, 'train', config.data.resolution,
            num_epochs_per_epoch=config.data.epochs_per_train_epoch,
        )
        val_dataset = scannetpp.get_scannet_test_dataset(
            config.data.root, alpha=0.5, beta=0.5,
            resolution=config.data.resolution, use_every_n_sample=100,
        )

    print("Initializing DataLoaders...")
    data_loader_train = torch.utils.data.DataLoader(
        train_dataset, shuffle=True, batch_size=config.data.batch_size,
        num_workers=config.data.num_workers
    )
    data_loader_val = torch.utils.data.DataLoader(
        val_dataset, shuffle=False, batch_size=config.data.batch_size,
        num_workers=config.data.num_workers
    )

    # --- TRAINING ---
    print('Training')
    num_devices = config.devices if isinstance(config.devices, int) else 1
    
    trainer = L.Trainer(
        accelerator="gpu",
        benchmark=True,
        callbacks=[
            L.pytorch.callbacks.LearningRateMonitor(
                logging_interval='epoch', log_momentum=True
            ),
            export.SaveBatchData(save_dir=config.save_dir),
        ],
        check_val_every_n_epoch=1,
        default_root_dir=config.save_dir,
        devices=config.devices,
        gradient_clip_val=config.opt.gradient_clip_val,
        log_every_n_steps=10,
        logger=loggers,
        max_epochs=config.opt.epochs,
        strategy="ddp_find_unused_parameters_true" if num_devices > 1 else "auto",
    )
    trainer.fit(
        model, train_dataloaders=data_loader_train, val_dataloaders=data_loader_val
    )

    # --- FINAL TEST (CO3D) ---
    if dataset_name == 'co3d':
        print('Running final test on CO3D...')
        test_dataset = co3d_dataset.CO3DDataset(
            root=config.data.root, split='test', img_size=tuple(config.data.resolution)
        )
        test_loader = torch.utils.data.DataLoader(
            test_dataset, shuffle=False, batch_size=config.data.batch_size,
            num_workers=config.data.num_workers
        )
        test_results = trainer.test(model, dataloaders=test_loader)
        
        save_path = os.path.join(config.save_dir, 'co3d_test_results.json')
        with open(save_path, 'w') as f:
            json.dump(test_results, f)
        print(f'CO3D test results saved to {save_path}')


if __name__ == "__main__":
    config = workspace.load_config(sys.argv[1], sys.argv[2:])
    if os.getenv("LOCAL_RANK", '0') == '0':
        config = workspace.create_workspace(config)
    run_experiment(config)